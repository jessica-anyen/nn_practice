#load_predict.py内容如下：
import os
import cv2
import numpy as np
from keras.models import load_model
 
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
 
"""---------载入已经训练好的模型---------"""
new_model = load_model('my_model')
 
"""---------用opencv载入一张待测图片-----"""
# 载入图片
src = cv2.imread('w_7.bmp')
cv2.imshow("test", src)
 
# 将图片转化为28*28的灰度图
src = cv2.cvtColor(src, cv2.COLOR_BGR2GRAY)
dst = cv2.resize(src, (28, 28), interpolation=cv2.INTER_CUBIC)

#cv2.imshow(src) 
# 将灰度图转化为1*784的能够输入的网络的数组
picture = np.zeros((1, 784))
for i in range(0, 28):
    for j in range(0, 28):
        picture[0][28 * i + j] = (255 - dst[i][j])


# 用模型进行预测
y = new_model.predict(picture)
result = np.argmax(y)
print("the result is", result)
 
cv2.waitKey(2731)