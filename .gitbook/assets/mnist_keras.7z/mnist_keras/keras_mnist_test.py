import os
from tensorflow.examples.tutorials.mnist import *
from keras.models import *
from keras.layers import *
 
# 屏蔽waring信息
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
 
"""----------加载mnist数据集-------------"""
mnist = input_data.read_data_sets("MNIST_data/", one_hot=True)
trX, trY, teX, teY = mnist.train.images, mnist.train.labels, mnist.test.images, mnist.test.labels
 
 
"""----------配置网络模型----------------"""
# 配置网络结构
model=Sequential()
 
# 第一隐藏层的配置：输入784，输出100
model.add(Dense(100,input_dim=784))
model.add(Activation("relu"))
model.add(Dropout(0.5))
 
# 第二隐藏层的配置：输入100，输出100
model.add(Dense(100))
model.add(Activation("relu"))
model.add(Dropout(0.5))
 
# 输出层的配置：输入100，输出10，用了softmax的输出层结构
model.add(Dense(10))
model.add(Activation("softmax"))
 
# 编译模型，指明代价函数和更新方法
model.compile(loss='categorical_crossentropy',optimizer='adadelta',metrics=['accuracy'])
 
"""----------训练模型--------------------"""
print("training starts.....")
model.fit(trX,trY,epochs=20,batch_size=20)
 
"""----------评估模型--------------------"""
# 用测试集去评估模型的准确度
accuracy=model.evaluate(teX,teY,batch_size=20)
print('\nTest accuracy:',accuracy[1])
 
"""----------模型存储--------------------"""
save_model(model,'my_model')

